YMIR Culture Editor v0.4
Authored by Dundin, If you want to contact me, i'm most easily contacted on discord: Dundin
So onward to the cool stuff!	

In order to use the program, you should know:
 - The culture editor needs any files you want to edit in the directory "\Culture_Editor_Files\YMIR_Save_Files" unless you set otherwise in settings.
 - The location to find your culture files on a windows platform is in this directory:
	"C:\Users\[Your Name]\AppData\Local\Ymir\saves\[Game Name]\players"
 - When looking for your local culture files for a solo game your culture file will be "culture_10"
 - It's a good idea to make backups if you're editing a game's save file.
 - Really, make backups.
 - If your settings somehow get messed up (it may interfere with launching the program if it does) you can reset your settings by deleting the "Settings.txt" file and relaunching the program. If you have a particularly keen eye, you may notice the file isn't even there until you first ran the program.
 - Oh! and if anything blows up, please take a screen-shot and send it my way, i'll fix it ASAP.

What happens if you manage to accidentally damage your culture file.
 - The worst case scenario: YMIR should re-make part or all of the culture file.
 - Your culture point allocation will reset for better or for worse, alongside other possible changes.

This file has some modifiable values that are unknown. Change them at your own risk. 
   However if you happen to discover what they do represent, I'll greatly appreciate it if you let me know!.